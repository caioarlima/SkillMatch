package com.example.skillmatch

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val cliqueEsqueciSenha : TextView = findViewById(R.id.EsqueciSenha)
        val Cadastra : TextView = findViewById(R.id.Cadastrase)
        val Entrar :  Button = findViewById(R.id.botaoEntrar)
        val emailEditText : EditText = findViewById(R.id.InputEmail)
        val senhaEditText: EditText = findViewById(R.id.InputSenha)

        cliqueEsqueciSenha.setOnClickListener {
            val intent = Intent(this, EsqueciSenha::class.java)
            startActivity(intent)
            finish()
        }

        Cadastra.setOnClickListener(){
            val intent = Intent(this, CadastroTela::class.java)
            startActivity(intent)
            finish()
        }

        Entrar.setOnClickListener(){
            val emailString = emailEditText.text.toString().trim()
            val senhaString = senhaEditText.text.toString().trim()

            val MIN_SENHA_LENGTH = 6
            val MAX_SENHA_LENGTH = 20
            val senhaRegex = Regex("^(?=.*[0-9])(?=.*[a-zA-Z])(?=\\S+$).{8,}$")

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailString).matches()) {
                Toast.makeText(this, "Por favor insira um email válido", Toast.LENGTH_SHORT).show()
            }

            if (senhaString.length < MIN_SENHA_LENGTH || senhaString.length > MAX_SENHA_LENGTH) {
                Toast.makeText(this, "A senha deve ter entre $MIN_SENHA_LENGTH e $MAX_SENHA_LENGTH ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!senhaString.matches(senhaRegex)) {
                Toast.makeText(this, "A senha deve ter no mínimo 8 caracteres, incluindo letras maiúsculas, minúsculas e números.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
                val intent = Intent(this, ProcurarTrocas::class.java)
                startActivity(intent)
                finish()
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}