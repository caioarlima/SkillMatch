package com.example.skillmatch

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class EsqueciSenha : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_esqueci_senha)

        val senhaNova :EditText = findViewById(R.id.InputEmailSenha)
        val enviarCodigo : Button = findViewById(R.id.botaoEnviar)
        val codigoEditText: EditText = findViewById(R.id.InputCodigo)

        enviarCodigo.setOnClickListener(){
            val emailString = senhaNova.text.toString().trim()
            val codigoString = codigoEditText.text.toString().trim()
            val CODIGO_LENGTH = 6

            if (codigoString.length != CODIGO_LENGTH || !codigoString.matches(Regex("\\d+"))) {
                Toast.makeText(this, "O código deve ter exatamente $CODIGO_LENGTH dígitos numéricos.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

            Toast.makeText(this, "Código válido!", Toast.LENGTH_SHORT).show()

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailString).matches()) {
                Toast.makeText(this, "Por favor insira um email válido", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, MudarSenha::class.java)
                startActivity(intent)
                finish()
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}