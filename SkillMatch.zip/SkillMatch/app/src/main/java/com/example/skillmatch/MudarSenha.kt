package com.example.skillmatch

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MudarSenha : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mudar_senha)

        val senhaEditText: EditText = findViewById(R.id.InputSenhaMudar)
        val confirmarsenhaEditText : EditText = findViewById(R.id.InputConfimarMudar)
        val MIN_SENHA_LENGTH = 6
        val MAX_SENHA_LENGTH = 20
        val senhaRegex = Regex("^(?=.*[0-9])(?=.*[a-zA-Z])(?=\\S+$).{8,}$")
        val mudar : Button = findViewById(R.id.botaoMudar)

        mudar.setOnClickListener(){
            val senhaString = senhaEditText.text.toString().trim()
            val confirmarSenhaString = confirmarsenhaEditText.text.toString().trim()

            if (senhaString.length < MIN_SENHA_LENGTH || senhaString.length > MAX_SENHA_LENGTH) {
                Toast.makeText(this, "A senha deve ter entre $MIN_SENHA_LENGTH e $MAX_SENHA_LENGTH ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!senhaString.matches(senhaRegex)) {
                Toast.makeText(this, "A senha deve ter no mínimo 8 caracteres, incluindo letras maiúsculas, minúsculas e números.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (senhaString != confirmarSenhaString) {
                Toast.makeText(this, "As senhas não coincidem. Por favor, verifique.", Toast.LENGTH_LONG).show()
                return@setOnClickListener // Para a execução
            }

            Toast.makeText(this, "Senha Mudada com sucesso!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}