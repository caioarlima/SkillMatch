import 'package:flutter/material.dart';

class AppColors {
  static const Color black = Color(0xFF000000); 
  static const Color white = Color(0xFFFFFFFF); 
  static const Color cinza = Color(0xFF555555); 
  static const Color fundo = Color(0xFFFAFAFA); 
  static const Color roxo = Color(0xFF5610B9);  
}