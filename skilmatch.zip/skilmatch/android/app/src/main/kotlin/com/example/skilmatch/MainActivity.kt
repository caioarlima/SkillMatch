package com.example.skilmatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
